import React, { Component } from 'react';
import TreeUser from './Tree.User.jsx'
import ContentUser from './Content.User'
import { Layout } from 'antd'


const { Sider, Content } = Layout;
class USER extends Component {
    render() {
        return (
            <Layout>
                <Sider style={{ overflow: 'auto', height: '100vh', left: 0 }}>
                    <TreeUser></TreeUser>
                </Sider>
                <Layout >
                    <Content style={{ margin: '24px 16px 0', overflow: 'initial'}} >
                        <ContentUser></ContentUser>
                    </Content>
                </Layout>
            </Layout>
        );
    }
}



export default USER;