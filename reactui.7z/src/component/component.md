# 组件文件

Header 头部组件
Home 路由第一层主页面
Login 登入页面
Slider 侧边栏
Design 设计页面首页
SliderCard 左边表
SliderRight 右边属性显示
PublicComponent 公共组件

## 属性说明  

icons: 'edit'  图标
id: 8  ID
type: 'INPUT' 判断类型
width: 4  宽度
required: true 是否必须
message: "123" 错误提示信息
label: "输入框" 标题
defaultValue: "123" 默认值提示
disabled: false 是否可选
content: true 是否是直接组件  group为false
RadioValue: {value:'',name:''} 单选框组的组员
groupname: '' 单选框组的命名